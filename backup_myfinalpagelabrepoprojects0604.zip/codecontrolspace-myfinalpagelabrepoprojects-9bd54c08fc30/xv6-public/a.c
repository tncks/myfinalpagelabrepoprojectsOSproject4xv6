int countvp(void) {
    struct proc *p = myproc();
    if (!p) {
        return -1; // Error: No process found
    }

    pde_t *pgdir = p->pgdir;
    int count = 0;

    // Iterate through page directory entries
    for (int i = 0; i < NPDENTRIES; i++) {
        // Check if page directory entry is valid
        if (pgdir[i] & PTE_P) {
            // Get the virtual address range covered by this entry
            uint va_start = i * PGSIZE;
            uint va_end = (i + 1) * PGSIZE;

            // Limit va_end to process size to avoid unallocated regions
            va_end = va_end > p->sz ? p->sz : va_end;

            // Check for each virtual address in the range
            for (uint va = va_start; va < va_end; va += PGSIZE) {
                pte_t *pte = walkpgdir(pgdir, (void *)va, 0);
                if (pte) {
                    // Check for present (PTE_P) and user (PTE_U) flags
                    if ((*pte & PTE_P) && (*pte & PTE_U)) {
                        count++;
                    }
                }
            }
        }
    }

    return count;
}

int
countpp(void)
{
    struct proc *p = myproc();
    if (!p)
        return -1; // Error: No process found

    pde_t *pgdir = p->pgdir;
    int count = 0;

    for (int i = 0; i < NPDENTRIES; i++) {
        if (pgdir[i] & PTE_P) {
            pte_t *pgtab = (pte_t *)P2V(PTE_ADDR(pgdir[i]));
            for (int j = 0; j < NPTENTRIES; j++) {
                if (pgtab[j] & PTE_P)
                    count++;
            }
        }
    }

    return count;
}


// C
int
countptp(void)
{
    struct proc *p = myproc();
    if (!p)
        return -1; // Error: No process found

    // Calculate the total number of pages
    uint pages = 0;

    // Count user level page table pages
    for (int i = 0; i < NPDENTRIES; i++) {
        if (p->pgdir[i] & PTE_P) { // Check if page directory entry is present
            pages++;
            pte_t *pgtab = (pte_t *)P2V(PTE_ADDR(p->pgdir[i])); // Get page table
            for (int j = 0; j < NPTENTRIES; j++) {
                if (pgtab[j] & PTE_P) // Check if page table entry is valid
                    pages++;
            }
        }
    }

    // Count kernel level page table pages
    for (int i = 0; i < NPDENTRIES; i++) {
        if (p->pgdir[i] & PTE_P) // Check if kernel page directory entry is present
            pages++;
    }

    return pages;
}
